#!/usr/bin/env python3

from brain_games.games.calc import calco2


def main():
    calco2()


if __name__ == "__main__":
    main()
