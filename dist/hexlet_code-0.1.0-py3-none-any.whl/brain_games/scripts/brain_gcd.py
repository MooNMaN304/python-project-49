#!/usr/bin/env python3

from brain_games.games.gcd import big_del2


def main():
    big_del2()


if __name__ == "__main__":
    main()
