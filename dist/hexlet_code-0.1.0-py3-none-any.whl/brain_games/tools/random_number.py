import random


def number():
  number = random.randint(1, 100)
  return number

def special_number(start, stop):
  number = random.randint(start, stop)
  return number
