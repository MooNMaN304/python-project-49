import random


def number(start, stop):
    return random.randint(start, stop)
