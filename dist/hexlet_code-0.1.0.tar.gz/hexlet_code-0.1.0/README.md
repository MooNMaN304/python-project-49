### Hexlet tests and linter status:
[![Actions Status](https://github.com/MooNMaN304/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/MooNMaN304/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/ec7ee1436db4842256f1/maintainability)](https://codeclimate.com/github/MooNMaN304/python-project-49/maintainability)
