import random


def number():
  number = random.randint(1, 100)
  return number
