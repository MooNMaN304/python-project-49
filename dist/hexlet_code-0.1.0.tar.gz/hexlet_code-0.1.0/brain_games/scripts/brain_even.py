#!/usr/bin/env python3

from brain_games.games.even import del_of_two


def main():
    del_of_two()


if __name__ == "__main__":
    main()
